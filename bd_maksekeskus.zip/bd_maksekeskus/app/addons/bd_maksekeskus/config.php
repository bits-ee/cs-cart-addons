<?php

if (!defined('BOOTSTRAP')) { die('Access denied'); }

fn_define('MAKSEKESKUS_GW_TEST_URL', 'https://payment-test.maksekeskus.ee/pay/1/signed.html');
fn_define('MAKSEKESKUS_GW_URL', 'https://payment.maksekeskus.ee/pay/1/signed.html');