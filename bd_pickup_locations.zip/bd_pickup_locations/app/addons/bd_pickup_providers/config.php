<?php
if (!defined('BOOTSTRAP')) { die('Access denied'); }

define('BD_PICKUP_PROVIDERS_SMARTPOST_FI_URL', 'https://itella.ee/places/fi_apt.json');
define('BD_PICKUP_PROVIDERS_SMARTPOST_EE_URL', 'https://itella.ee/places/places.csv');
define('BD_PICKUP_PROVIDERS_OMNIVA_URL', 'https://www.omniva.ee/locations.json');
define('BD_PICKUP_PROVIDERS_DPD_URL', 'https://dpdbaltics.com/PickupParcelShopData.json');
define('BD_PICKUP_PROVIDERS_CARGOBUS_URL', 'cargobus.csv');
